"""Record a subprocess independently of a chat session; argv must contain no secrets."""

import argparse
import os
import signal
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from driveserve.evidence import Run, process_identity, now

parser = argparse.ArgumentParser()
parser.add_argument("--kind", required=True)
parser.add_argument("--formal", action="store_true")
parser.add_argument("argv", nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.argv[1:] if args.argv and args.argv[0] == "--" else args.argv
if not command:
    parser.error("a command is required")
root = Path(__file__).resolve().parents[1]
run = Run(root, args.kind, {"argv": command}, formal=args.formal)
print(run.path, flush=True)
child = None
def interrupted(signum, frame):
    raise KeyboardInterrupt(f"signal {signum}")
signal.signal(signal.SIGTERM, interrupted)
try:
    with (run.path / "command.log").open("w", buffering=1) as stream:
        child = subprocess.Popen(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        run.manifest["child_process"] = process_identity(child.pid)
        run.manifest["child_process_group"] = child.pid
        run.save()
        while True:
            try:
                code = child.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                run.manifest["heartbeat_at"] = now()
                run.save()
        # The command may have spawned a grandchild; do not finalize a log while it can still write.
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    run.finish("completed" if code == 0 else "failed", {"returncode": code})
except BaseException as exc:
    if child is not None:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        child.wait(timeout=10)
    run.finish("interrupted", {"error": str(exc)})
    raise
print(f"{run.manifest['run_id']}: {run.manifest['status']}", flush=True)
sys.exit(code)
