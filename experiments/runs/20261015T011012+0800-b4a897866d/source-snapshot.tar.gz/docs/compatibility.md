# 源码预检与实机兼容矩阵

源码基准：vLLM v0.8.5 / `ba41cc90e8ef7f236347b2f1599eec2cbb9e1f0d`。源码路线与实际运行分别列出；小样本兼容检查不等于六主线验收。

| 主线 | 真实源码入口 | 发现 / 下一步 |
|---|---|---|
| M1 | `vllm/entrypoints/openai/serving_chat.py` → `vllm/engine/async_llm_engine.py` → `vllm/engine/llm_engine.py` → `vllm/core/scheduler.py::Scheduler.schedule`（1493） | 待完整函数链与真实事件插桩、开销对照 |
| M2 | `vllm/core/block_manager.py::SelfAttnBlockSpaceManager`；`vllm/core/block/prefix_caching_block.py::_maybe_allocate_evicted_block_id`（324） | 原生淘汰只处理 refcount=0 的缓存块；必须保留 hash/引用计数不变量，不得仅外部排序 |
| M3 | `vllm/spec_decode/spec_decode_worker.py::execute_model`（454）及 `_run_speculative_decoding_step`（758） | `num_lookahead_slots` 在运行请求中传递且广播给其他 worker；固定 K=3 已跑通派生 Draft；原始 Draft 在 1258 行词表断言失败，控制器、EOS/rollback 扩展验证与训练待完成 |
| M4 | `vllm/model_executor/layers/quantization/awq.py::AWQConfig` | 该原生 AWQ 路径要求 FP16 激活，最低 capability=75；group128 的原生 AWQ 已加载推理；自主导出、多 Group Size 与 Marlin 待检查，不用 BF16 冒充此路径的 W4A16 |
| M5 | `vllm/model_executor/layers/rotary_embedding.py::RotaryEmbedding.forward_cuda`（167）；`csrc/cache_kernels.cu` | 已定位所选 CUDA RoPE 后接 reshape_and_cache_flash，计划 NeoX/GQA/FA 布局；独立融合已编译与验证，边界及固定 FlashInfer 核查见 rope-cache.md |
| M6 | `vllm/attention/backends/flash_attn.py`（808 等） | 存在 `flash_attn_varlen_func` 及 fa_version 参数；TP2 已真实运行，P2P 不可用且自定义 all-reduce 关闭。FA2 合成 Prefill 已捕获 flash forward kernel 并通过 FP32 参考；Nsight已采集70,804个kernel，见engine-diagnostics.md；拓扑 NODE，无 NVLink |

| 配置项 | 当前事实 | 验收状态 |
|---|---|---|
| GPU | 2×报告 49140 MiB 的 RTX 4090；独立环境及真实服务均运行 | 单卡与 TP2 冒烟成功；未测真实 24GB 卡 |
| 驱动 / 编译器 | 550.163.01 / nvcc 12.1 | torch 2.6.0+cu124 / vLLM 0.8.5，153 项依赖锁；全新环境重建通过 |
| Target / Draft | revision 固定；tokenizer 文件同 hash，模板及 BOS/EOS 相同，配置词表维度不同 | Target 已加载；原始 Draft 失败，零填充派生后固定 K=3 成功，32 条贪心输出一致 |
| AWQ | 固定上游 W4A16/group128，强制原生 awq；32/32 成功，30/32 正确 | reports/s1-awq-format-smoke.json；未自主校准，Marlin 未测 |
| FA2 kernel | FP16 causal GQA，长度 127/512，FP32 参考通过，profiler 捕获 flash forward | reports/s1-fa2-smoke.json；不是 Nsight 或性能比较 |
| CUDA Graph | clean SHA 95e48c3，捕获 batch 1/2/4，32/32 成功、31/32 正确 | reports/s1-graph-clean-smoke.json；V0 图模式，未测 torch.compile |
| TP2 | 32/32 成功、31/32 全字段正确，requests + measurement 重聚合一致 | reports/s1-tp2-smoke.json；不是吞吐提升证据 |

链接中的行号只适用于上述固定 SHA。恢复源码使用 `scripts/restore_upstream.py`。上游代码不能记为个人实现；这份预检不满足 M1-01 的完整调用链，相关实机证据只支持表内限定范围，不能替代 S2 的六线验收。
