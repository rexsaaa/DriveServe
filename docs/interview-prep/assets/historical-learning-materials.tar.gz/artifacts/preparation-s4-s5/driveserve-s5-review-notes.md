# S5 接续审阅（准备笔记，未实施）

S4 formal r1运行期间只读审阅所得；不能将本笔记当已验证功能。

1. benchmark_speculation.py目前显式拒绝quantization+非target模式，这是本项目CLI限制，尚不证明vLLM不支持。EngineArgs已用speculative_config字典，config.py创建Draft ModelConfig的quantization来自SpeculativeConfig自身；须阅读并实跑确认FP16 Draft未继承AWQ Target格式。新比较应FP16 Target/FP16+trained fixed/quant Target/同quant+trained fixed（必要时adaptive额外诊断），greedy/随机参照各自Target，不能相对FP16宣布量化保持分布。
2. 同脚本目前硬编码只取split=dev；给--dataset test不会自动评final-test。需显式受支持的--split并绑定manifest/hash、记录实际数量；冻结协议后一次性运行保留所有结果，不借最终test重选阈值或训练/校准源。
3. openloop草稿实际使用asyncio/aiohttp，旧设计文档仍写线程池，应更新。实际header-send trace与planned timestamp区分；全程deadline从planned arrival起，包含客户端semaphore等待，timeout未发送也保留分母。
4. 草稿未做所有输入预检：offset/timeout必须有限，ID唯一，endpoint需在建task前验证；无效配置直接失败，不让某task绕过记录。finish_reason仅接受stop/length，完整DONE、usage类型及数量、prompt_tokens必须匹配，拒绝redirect。新增恶意慢滴流、未知finish、缺usage、坏JSON、HTTP错误、排队超时、取消保存等真实本地HTTP fixture；fixture不是模型成绩。
5. Goodput须在最终测试前冻结阈值和分母。建议自然业务与合成混合压力分别报告，前者不填充，后者保留长度/来源并报告填充降质。开始采用S3观察指导开发试跑：单卡512/c8约12.38req/s、1536/c8约5.71；双副本17.16/9.60；TP2三轮平均11.41/4.69且首轮更快。固定共同到达率可选4与12 req/s，需一次开发冒烟确认客户端可承载，再冻结，不声称这已经是最佳负载。
6. 每cell预算可为256请求×三独立进程，明确P99探索性，非10000请求稳定尾部。用seed生成独立到达轨迹，保留planned/sent/first/last/finish、发送lag和每endpoint负载；吞吐/goodput分母取预定到达窗口与最后完成的较大值，包含drain，并明确计算。比较同两卡预算replica/TP2，single另列效率；全局maxseq、KV预算、Graph/APC/chunked、轮询在配置明确。
7. 已有cache×scheduler引擎合成对照需在S5保留明确组合证据，并补业务质量/最终profile验证；独立CUDA维持单算子归档，不强行声称全服务融合。没有要求所有功能同一进程开启；APC/spec是否冲突须实际配置检查/启动记录，不能凭猜测写不兼容。
8. TP2首轮速度异常原因仍未知。S5不复用S3单次最快数作baseline；新的三部署匹配复测保留全run与硬件前后快照。可考虑进程内低频NVML遥测，但它自身开销与所有配置一致性须记录；不在正式运行中临时加profile或额外GPU任务。
9. 最终质量门槛必须事前写清。当前dev128门槛是FP16正确数-1且完成/JSON有效；若扩到final256可预先固定允许差2条，但这仅工程容差，不是统计非劣效或安全保证。选择规则若最终门槛失败须回退FP16，不能依据错误样本调提示后再宣称原冻结test通过。
