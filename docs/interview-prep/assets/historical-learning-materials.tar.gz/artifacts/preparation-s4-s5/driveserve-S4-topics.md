## 从S3到S4：两个独立深化专题

S4选择的是冷热策略索引结构和独立CUDA工作分配。没有新增模型、重训Draft或重做相同AWQ来增加工作量；M1/M3/M4/M6保持S3已验收实现，改变引擎入口的M2与新增CUDA路径M5分别补回归。S4的边界与三轮汇总见本阶段acceptance/replay/resume/coverage及根目录s4-depth-results；只有实际通过后才能称已验收。

### 专题A：用三个堆保持原淘汰语义

为什么做：S3每次evict扫描整个free_table，128块合成场景的累计扫描是约13–16ms，不是10秒级引擎时间的主要部分。研究机会是池扩大时线性扫描的维护成本，而不是已证明服务瓶颈。原生vLLM仍负责refcount、hash、block table和APC；S2/S3个人策略负责有效复用计数与冷优先。S4不变更冷热阈值、TTL或调度，只更换零引用候选的索引。

具体增量在`driveserve/heap_policy.py::HeapColdHotEvictor`，继承ColdHotEvictor以保持旧hook的isinstance行为。`_cold`和`_hot`保存(last_accessed,-num_hashed_tokens,block_id,generation)，`_expiry`保存(deadline,block_id,generation)，`_versions`保存当前版本，`_by_hash`把resident的唯一内容hash映射到free block。每次更新递增_serial，旧堆条目被懒惰丢弃；不能只检查block_id，因为物理块释放/重用后id会再出现。

一次请求首次prefill实际跳过连续完整prefix时，旧`record_prefix_reuse`仍从真实allocator拿hash并验证正引用，调用evictor.record_reuse。活动块没有候选索引，但reuse历史仍更新；最后引用释放后add按当前clock分类进入cold/hot。重新激活remove删索引版本与hash映射，保留reuse历史。真正evict先用expiry把过期hot变cold，再从cold取合法版本；cold为空才选hot。选中后删free_table、版本/hash索引和reuse，由上游分配器重用该块。

TTL采用与旧is_hot相同的now-last<ttl谓词。浮点last+ttl不是减法谓词的精确逆：用nextafter找到最早使减法到期的可表示时刻，并在弹出时再次检查。12个邻接浮点边界用例比较旧/新victim；这是保持边界语义的工程工作，不宣称实数运算精确。

懒惰删除如果无限积累会泄漏索引状态。`_compact`在三堆条目总数超过max(64,4×free_count)时从当前free_table重建；元数据版本表保持与候选集合一致。完整复杂度不是“所有操作O(log N)”：通常操作是对数维护，但过期批量降级、垃圾弹出和重建会有长尾；内存也从一份候选表变为多个索引。原is_hot/reuse规则不变，冷热优先仍可能牺牲长请求或某些缓存工作负载。

正确性证据是20000步真实旧/新策略类的相同clock操作，每步free_table、reuse、索引集合一致且每次victim一致；5000次反复touch/reuse检查索引上界和重建，再排空并确认空池拒绝。真实vLLM allocator分别scan/heap各4测试，覆盖活动共享块不能淘汰、hot保留/旧hash清理、dedup不计有效复用、mutable fork copy-on-write。Graph生命周期两组各792不变量快照、32共享块、2取消、1次RECOMPUTE；16请求token/status相同。这些测试声明的是受支持单卡V0非chunked路径，不是swap/beam/TP所有情况。

性能对照不只测evict：每规模128/1024/8192/16384，每run256轮evict+add+两次reuse+update+remove+add，计入索引维护与重建；初始化单列且标明tracemalloc开销。报告完整操作中位数、P99、最大值、256轮总时间、Python allocation和峰值。256个相关操作不能当256个独立环境，三进程重复才是run级统计。引擎另跑native/scheduler/scan cache/both/heap cache/both，六配置保持同Graph/4、128块、36请求，不拿CPU微基准比例当服务吞吐改善。

追问：为什么堆更快也可能不该默认？小池不是总服务瓶颈且有额外内存与重建长尾。为什么需要三个堆？两个负责冷/热相同排序，第三个让hot过期后即使没有新请求也能回到cold优先级。为什么记录generation而不是删任意堆位置？标准heap不支持高效任意删除，版本让重用安全、配合有界重建限制陈旧条目。未来若需要进一步改进，可研究增量重建或更强的规模/尾延迟约束，但本阶段没有实现这些能力。

### 专题B：分开验证head tile与half2

为什么做：S3原型一token一CTA，T1只发一个256线程block，每个线程需循环多对Q维度。S4把相同张量工作划成每token8个4-head tile；首7个tile负责28Q头，末tile负责4K头和对应V cache写入。每个head/dim及有效唯一slot只有一个写者，所以没有跨CTA同步。原v1和上游分步保留；新路径仍不是服务attention backend。

`csrc/rope_cache_tiled.cu`中scalar每CTA256线程、每线程一对NeoX半区元素；half2每CTA128线程、每线程两维的half2 pair。旋转为rx=x*c-y*s、ry=y*c+x*s，使用__hmul2_rn/__hsub2_rn/__hadd2_rn分开舍入，避免FMA改变旧FP16中间语义。cache偏移仍slot×KVH×D，V平面在cache_slots×KVH×D之后，负slot只旋转Q/K而不写cache。

向量化需要projection/table/cache指针4字节对齐且row stride为偶数；contiguous不保证storage_offset对齐。`half2_compatible`按实际地址/stride判断，显式half2遇不对齐拒绝且不改存储。`fused_v2(auto)`对T≤32选可用half2，否则scalar；T>32走原v1。阈值32在正式比较前固定，仅是候选策略，不保证所有形状最优。原`fused`继续调用v1，不暗中改变已有已发布路径。

正确性覆盖12个T（含0与边界）、block16/32、padding0/1/128、三类半字offset、有限极值/次正规数及负/边界slot；每方案核对Q/K/cache、V不变、未写slot与padding不变。与上游逐元素相等和独立PyTorch张量参考容差分别记录，finite极值可能算出inf/NaN，比较保持上游语义而不声称输出总有限；signed zero属于数值相等，不保证位模式符号一致。275项包括不同方案和边界，不是275次独立进程。99项sanitizer检查零错误，三新入口各24拒绝及只读索引共享正例通过；原alias修复规则仍适用。

消融是upstream separate、原v1、scalar tiles、half2 tiles、固定auto，T1/8/32/128/512/2048。每shape每run随机方案顺序、20个CUDA Event样本、每Graph100操作，三进程独立；编译、热身、分配、重置、公开入口同步校验在外。重复原地旋转属于热cache microbenchmark，不能外推全模型冷数据或HTTP TPOT。host dispatch和checked API成本不在这些kernel时间里。

追问：为什么scalar大T可能更慢？更多CTA带来更多调度/重复table读取，小T并行度优势不一定在大T继续存在；这是与布局一致的解释假设，未用硬件计数器隔离每一项因果。half2为什么单列？分块改变并行度，向量化改变每线程工作，只有分别测才能分离两者。为什么不凭最佳shape切换全服务？当前算子独立、支持固定FP16形状，服务接入还涉及QKV来源、KV布局、Graph捕获及占比；本阶段没做，不算端到端优化。

## S4知识与面试组织

两分钟介绍在S3六线基础上加两句：我把冷热候选的线性扫描改为有界版本堆，保留精确规则并报告内存/长尾成本；我通过head tile和half2消融研究独立融合CUDA的形状边界，保持旧FP16舍入与回退入口。结论用本阶段真实三轮表，不能省略服务无稳定收益或大T退化。

十分钟路线仍从任务/数据→证据/环境→六线请求流，深化只在M2的evict路径和M5的thread/head映射展开。深入追问可手算旧/新淘汰键、version如何防块复用、TTL浮点边界、重建为何影响最大延迟、half2地址对齐、FP16舍入及Graph Event边界。用户尚未复述或接受追问，工程验收不等于独立掌握。
