## S4 新实现回放与受影响路径

S1–S3环境、模型、训练/量化产物恢复及六线流程在上面的累计入口保留；要逐字节重聚合旧结果使用对应tag和保存的state，不把新机器性能套到旧baseline。当前S4新增核心不要求重训/重复校准；原scan和CUDA fused(v1)入口继续保留。

先确认两卡空闲、没有活着的旧runner，用本次独立GPU Python与固定policy overlay。实际命令：

```bash
python3 scripts/check_heap_policy.py --repeat 1
PYTHONPATH=/hy-tmp/driveserve/vllm-policies-v2:/hy-netdisk/jq/project/DriveServe VLLM_USE_V1=0 DRIVESERVE_CACHE_IMPL=heap /hy-tmp/driveserve/venv-rebuilt/bin/python scripts/check_policy_allocator.py
/hy-tmp/driveserve/venv-rebuilt/bin/python scripts/benchmark_policies.py --stage S4 --variant both --cache-implementation heap --graph --max-seqs 4 --suite lifecycle --trace
/hy-tmp/driveserve/venv-rebuilt/bin/python scripts/benchmark_policies.py --stage S4 --variant both --cache-implementation heap --graph --max-seqs 4
```

scan/heap是实现开关；cache/both是功能组合，native/scheduler只能scan参数，因为没有冷热候选算法可切换。上游refcount/hash/page table并未由heap替代。CPU规模脚本产生真实类的差分、维护和内存观察，不是GPU吞吐；正式独立重复用三份计划中不同repeat。

CUDA新实现由extension_v2编译独立module，保留原.cu/.cpp。需让固定环境的ninja在PATH前部；编译产物在/hy-tmp，可重新生成，迁移需重新验证driver/CUDA/arch及正确性。

```bash
PATH=/hy-tmp/driveserve/venv-rebuilt/bin:$PATH /hy-tmp/driveserve/venv-rebuilt/bin/python scripts/check_rope_depth.py --stage S4 --repeat 1 --benchmark
PATH=/hy-tmp/driveserve/venv-rebuilt/bin:$PATH /usr/local/cuda/bin/compute-sanitizer --tool memcheck --error-exitcode 99 /hy-tmp/driveserve/venv-rebuilt/bin/python scripts/check_rope_depth.py --stage S4 --quick --sanitizer
/hy-tmp/driveserve/venv-rebuilt/bin/python scripts/check_rope_contract.py --stage S4 --variant half2
```

`fused_v2(...,variant='auto'|'scalar'|'half2'|'v1')`是检查入口；`fused(...)`仍是原v1。半字offset/奇数row stride时auto小T走scalar，显式half2报错；largeT auto回v1。不能在Graph捕获内调用包含CPU索引检查的公开入口；计时脚本在外校验后调用raw extension，这一差异须保留。memcheck与性能不能混合。

新正式三轮每轮8任务，按configs/s4-timing-plan-r1/r2/r3.json依次执行，每轮用新state目录；不能覆盖已有reports封存state。30秒心跳和PID/boot/start_ticks用于接管；失败整单元重测，训练恢复协议与benchmark重复不是同一件事。runner的inner_kind可从sanitizer中间进程的已校验wrapper日志找真实子run，不把没有manifest的任务冒充已验证。

```bash
python3 scripts/run_experiment_plan.py --plan configs/s4-timing-plan-r1.json --state artifacts/my-s4-r1/state.json
python3 scripts/analyze_s4_boundaries.py --state reports/s4-boundaries-state.json --report artifacts/reports/s4-boundaries-recheck.json
python3 scripts/analyze_s4_replication.py --states reports/s4-timing-r1-state.json reports/s4-timing-r2-state.json reports/s4-timing-r3-state.json --report artifacts/reports/s4-depth-recheck.json
python3 scripts/render_s4_depth.py --report artifacts/reports/s4-depth-recheck.json --output artifacts/reports/s4-depth-recheck.md
```

三轮原始结果全部完成前，含r2/r3的命令只是最终复算入口，不代表文件当前已存在。实际完成情况以progress/state/验收报告为准。模型/权重没有新增，沿用先前144对象的完整OSS收据；新增代码、CPU/GPU原始记录和阶段讲解由GitHub留存并独立读回。S4不包含final-test，不使用旧S3的TP2最快轮来证明新阶段服务性能。
