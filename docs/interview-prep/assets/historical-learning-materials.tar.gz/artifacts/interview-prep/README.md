# DriveServe 面试学习资料入口

本目录集中保存个人面试准备资料。新 session 使用同一工作区时，先读本页，再按当前任务打开对应文档。

| 文件 | 用途 |
|---|---|
| [最低准备指南](DriveServe-v1.0-面试最低准备指南.md) | 明确六条主线需要理解什么、能解释到什么程度 |
| [nano-vLLM 三方源码对照](nano-vllm-comparison.md) | 从精简生成循环理解模块关系，再对照固定 vLLM 与 DriveServe 的实际改动；含本地源码链接与版本记录 |
| [第一轮运行清单](interview-benchmark-commands.md) | 第0节环境准备与R1–R8任务包，包含命令、观察点和完成标准 |
| [进阶附录](interview-benchmark-advanced.md) | 训练恢复、重新校准、heap、CUDA v2及完整复现，第一轮后按需选择 |

## 接续学习时的约定

- 当前目标是面试最低准备，先完成一项小操作，再解释原理；回答简短，按需深入，保持六条主线覆盖。
- 框架概念不清楚时，先按三方源码对照的四站阅读：生成循环、调度与缓存、输入准备、模型与算子。nano-vLLM 是独立参考实现，DriveServe 直接复用固定 vLLM；源码已准备不代表用户已经掌握。
- 学习操作由用户亲手执行，助手解释命令、观察结果并协助排错；代跑演示不计为用户独立完成。
- 在项目根目录 `/hy-netdisk/jq/project/DriveServe` 执行命令。学习分支为 `interview-practice`，原分支为 `main`，`DS_LEARN="$DS_REPO"`；不要在本资料目录运行实验脚本。
- 接续时先核对实际分支、Git状态、清单勾选和用户的运行记录。本文整理时R1–R8均未勾选，不能据此推断后续完成情况；不要自动重跑已有实验。
- 操作记录位于项目根目录下的 `artifacts/learning/notes/`，原始实验产物位于 `experiments/runs/`。记录实际run路径、代码SHA和本人完成程度；六线讲解与简历数字须能回到证据。
- 新 session 不会自动继承聊天内容或终端变量，继续运行前按清单设置环境。训练、校准等进阶项目不自动扩入第一轮。

本目录被 Git 忽略，在当前工作区的分支和 session 之间共用，修改会反映到同一份文件；不会随 Git 分支保存版本，也不会通过 `git clone` 自动出现在另一台机器。资料备份与实验资产留存按[存储说明](../../docs/storage.md)处理。

## 给新 session 的开场说明

复制下面这段，再补上你实际做到的位置：

```text
请先阅读 /hy-netdisk/jq/project/DriveServe/artifacts/interview-prep/README.md。
我正在做 DriveServe 面试最低准备，按第一轮清单逐项学习，回答简短。
当前做到：第0节 / R__。
上次操作及结果：……；运行记录路径：……（尚未执行就写尚未执行）。
这次想继续：……。
```
