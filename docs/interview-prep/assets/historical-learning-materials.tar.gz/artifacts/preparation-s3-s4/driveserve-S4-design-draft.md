# S4 候选设计（准备稿，未验收）

进入正式验收前须S3 accepted；当前实现均未接入仓库，CPU/GPU实验均待执行。保留六主线，不改任务、模型或默认FP16配置。候选来自S3缓存扫描的实际成本与CUDA实际微基准，并不宣称它们是总服务的主要瓶颈。

| 候选 | 证据/问题 | 实质改动 | 对照与成本 | 决定 |
|---|---|---|---|---|
| 冷热淘汰索引 | 当前evict每次扫描全free_table；S3r1最终场景累计13–15ms，128块只是很小池 | 两个顺序堆+TTL过期堆，版本去除陈旧项，按比例重建，保持原判定及tie-break | 先测128/1024/8192/16384真实策略操作曲线；随机轨迹逐次victim等同、真实allocator生命周期；scan/heap×GPU四组必要回归；报告内存和重建尾部 | 候选A；先确认规模成本，再决定是否默认启用 |
| CUDA小T并行度/向量化 | 当前一token一CTA；T1仅一CTA，实测约2.73μs，但未证明服务占比高 | 每token8个head tile；分别scalar与half2做消融；小T分派，大T保留v1 | 上游分步/v1/tiled-scalar/tiled-half2/dispatch；独立3进程，数值/未写区/奇数padding/offset/极值、memcheck；编译/检查开销在外单列 | 候选B；不进入服务、不推导TPOT收益 |
| 接受率+成本K | Graph下trained adaptive对fixed增量很小；长输出贡献分布不同 | 需新增可靠成本估计并控制同步扰动 | 与现有K分离、三轮模型重复、随机分布回归；跨负载估计稳定性成本较高 | 暂不选，保留到后续，不把窗口参数扫作深化 |
| TP2通信/数值 | 长填充第4token近似/并列已定位；两卡无NVLink | 算法层规避不等于通信优化，不能改标签抹去质量差异 | 需独立通信profile/高精度归约验证；超出当前两个独立专题最短闭环 | 保持诊断和质量限制，不强推为默认 |

A保持上游所有refcount/hash/block-table操作，只替换零引用候选的选择数据结构。冷热仍按2次实际完整前缀跳过、30sTTL，冷/热内按last_accessed、-num_hashed_tokens、block_id排序。堆记录携带单调版本，防止physical block id复用后陈旧项选中活动块。到期必须主动将hot候选降为cold；懒惰弹出若不设重建界限，会随请求数无限膨胀。浮点TTL边界必须与旧is_hot谓词一致。索引新增成本在add/update/remove/reuse，不能只测evict快而隐藏维护开销。

B以packed Q28/KV4 D128、完整NeoX FP16为限。每个4-head tile拥有不重叠的Q/K和对应KV位置，不需要跨CTA同步；有效slot仍要求唯一。half2只在指针对齐及偶数row stride时使用，并以独立hmul2/hsub2/hadd2保留中间FP16舍入，不启用fast-math/FMA偷换数值。奇数stride或半字offset回退scalar，原v1公开入口保持独立。需要用实测决定是否保留dispatch；负收益允许回退，不删除失败路线。

既有M1插桩/M3训练与分布/M4AWQ/M6FA2部署沿用固定版本并做受影响回归；不重复训练或量化来充当专题进度。最终组合、final-test及发布仍属于S5/S6。
