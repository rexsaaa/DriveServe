# S5 兼容矩阵与profile选择（草稿，待正式重复及最终质量）

| 组合/能力 | 实际验证范围 | 已知结果/选择 | 证据 |
|---|---|---|---|
| 原生APC＋自研cache×scheduler | 同一policy overlay，scan，Graph，wave8/maxseq4，128KV块，dev128 | 四种策略128输出相同、121正确、复用21824；自然业务没有额外复用收益。S4压力与生命周期保留 | s5-business-development.json；s4-depth/s4-boundaries |
| FP16 Target＋蒸馏fixed＋原生APC | spec overlay，Graph，K4，512块，137条含EOS/长度/上下文 | 当前开发137输出/status与同APC Target相同、121/128；需正式重复，不能拿无APC旧数作本次baseline | s5-apc-development.json |
| FP16 Target＋adaptive＋APC | 实际开发已运行，待统一聚合 | 正式结论待三轮 | s5-apc-full-state（待归档） |
| AWQ领域group128＋FP16 Draft fixed/adaptive | quantization独立设置，FP16 Draft无继承AWQ；APC关闭开发137条 | 137输出一致、121正确；单次比AWQ Target慢。APC开启完整组合仍在检查 | s5-development-composition.json |
| AWQ＋随机adaptive | 真实Graph，temperature0.8、seed37，含拒绝/bonus/EOS/长度/无提议 | 实际K2/3/4，接受与宽度审计；不是随机输出逐token相同或语言分布总体检验 | s5-awq-random.json；S2已知概率律CUDA采样验证 |
| 自研冷热/长度调度＋spec同一进程 | 现有policy与spec overlay独立，未合并运行 | 最终不启用此未测试组合，不宣称上游冲突。cache×scheduler与原生APC×spec分别有证据 | patches两个overlay；各自入口 |
| 独立RoPE-cache CUDA | v1/scalar/half2/auto，FP16 NeoX Q28/KV4 D128 | 六shape三轮微基准与边界/内存检查；没有接服务，不计服务TPOT收益 | S4最终报告 |
| 原生APC＋单卡/双副本/TP2 | vLLM原生轮子，Graph/FA2，APC，非chunked；全局maxseq8，两卡case同硬件 | 开发3×128完成；正式3×3×1024待运行 | s5-openloop-development.json |

默认配置以最终质量与性能证据确定。动态K、heap和AWQ×spec不因“实现了”自动启用；TP2在S3首轮较快的原因仍未知，新阶段数据不能倒推因果。三部署比较不共享固定KV token容量，实测自动容量和同显存比例须记录。上游APC/Graph/FA2/AWQ/TP是复用能力；自研贡献是生命周期策略、长度调度、运行时K及采样修复、蒸馏recipe与实际训练、校准/敏感性实验、自写融合CUDA与证据链。
