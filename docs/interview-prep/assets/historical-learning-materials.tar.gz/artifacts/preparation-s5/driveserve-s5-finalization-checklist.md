# S5接续验收操作（准备清单，未完成）

1. 当前r1在29cefb3运行：configs/s5-timing-plan-v2-r1.json → artifacts/s5-timing-v2-r1/state.json；13任务结束前不改tracked源码、不运行其他GPU/OSS任务。随后归档r1 state及全部wrapper/inner，实际运行composition/openloop聚合，保留每次结果。中文S5关键提交、push后r2反序/r3轮转启动，执行代码应保持一致。
2. 最终正式报告建议reports/s5-composition.json、reports/s5-openloop.json；三轮共39进程，其中18六模型APC、12四policy、9服务。三部署每run4×256=1024请求，总9216；不要求所有SLO或质量通过才能记录真实实验，但推荐要受冻结门槛约束。每个模型run137条含9边界，policy128条业务。全部source/config/workload/environment指纹匹配；2失败HTTP开发报告保留。
3. /tmp/driveserve-render-s5-results.py尚未集成/实际运行，可在r1结束的文档/聚合工作单元集成，生成docs/s5-results.md；不改正在使用的执行模块。更新累计文档时不要把单轮当三轮。
4. 最终test协议configs/s5-final-quality.json、十profile调用plan已在29cefb3冻结，至今未送模型。dev正式重复之后执行configs/s5-final-quality-plan.json；完整256/每profile一次，无profile重选/提示调参。scripts/analyze_s5_final.py目前仅编译、未实际执行，按真实运行可能有集成错误需保存失败后修复报告，不重新调测试样本。
5. 最后GPU回归：受影响执行路径由正式39与final十profile覆盖；原独立CUDA未改，S4源码/hash与275/99检查可引用；可加S5独立full/contract/memcheck实际核验（需版本化计划），不能没跑就标完成。M1/M4训练与校准资产不重训重做；沿用S2/S3实际恢复证据。
6. OSS144对象51,794,986,555bytes，无新权重。可参照scripts/verify_s3_release.py和reports/s3-restore/当前小成员恢复做最终实际读回；大权重全量读回仍历史，不能把小探针称第二次全模型迁移。
7. S5累计材料：以docs/stages/S4六线全景为基础扩写到S5，新增组合矩阵、最终profile、开/闭环口径、质量/速度取舍、失败修复、原始索引；27条coverage全保留。/tmp/driveserve-S5-topics.md、S5-compatibility.md为早期草稿（有旧单次数字，需用最终正式替换/标历史），不可照抄成完成。
8. 通过stage S5本地audit_evidence（require-tracked、全部receipt/doclinks）→推送release candidate→独立GitHub checkout跑39CPU（用固定venv含aiohttp；禁止跳过HTTP7tests后说39通过）→精确重聚合composition/openloop/final/table及audit。新的verify_s5_release.py待实现，不复用S4脚本的28count当当前。所有新增run和最终图/日志hash齐全后才accepted/tag stage-5-candidate。
9. 紧接S6：README/quickstart/reproduce/finalreport/resultsindex/资产manifest/阶段tag获取/六条事实简历/完整累计学习；干净checkout验证脚本、链接、获取小资产，GPU复现明确引用S5冻结实现，不伪称再次跑GPU。最终验收tag，不改仓库可见性，不创建公开GitHub Release。用户掌握仍未核验。
10. persistent goal active；S5或r1阶段结束不是全任务完成，继续到S6验收。工具授权danger-full-access/never，不传sandbox_permissions、不动Codex认证/API隧道/tmux、不依赖Mac、不spawn代理。
