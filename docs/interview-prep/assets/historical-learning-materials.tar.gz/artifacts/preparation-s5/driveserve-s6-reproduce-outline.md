# 最终复现入口（待S5/S6验证后集成）

按证据层级分开：CPU重算不调用模型；GPU重测生成新的run；完整训练/校准复现使用已有锁和独立目录，不覆盖原结果。参考S5固定源码的GPU最终回归，S6工具与文档改变不构成再次GPU测速。

1. 干净checkout和CPU快速开始。Python3.11 Linux x86_64；pip支持--python。基础命令不需要CUDA，完整39项含HTTP必须恢复aiohttp wheel并加--http-tests。
2. OSS账户与来源。GitHub不包含大权重；OSS需要本项目账户权限，凭据由平台CLI管理。按收据恢复，归档/内容双hash；旧环境快照路径有限，优先版本锁重建。
3. 基础wheelhouse恢复：38对象（inventory/provenance/36wheels），实际数字读最终收据。relocate_lock核对36hash并生成新锁；其他117条索引依赖仍需指定index，不声称离线完整wheelhouse。
4. GPU bootstrap保持原锁不变，--wheelhouse指定恢复目录。NV driver/nvcc仍是宿主依赖。S1同实例完整独立重建证据；S6新路径映射实测与CPU安装另存，不冒充宿主迁移。
5. 模型与附加层映射：target、draft_aligned；trained assets/distilled；AWQ assets/domain-g128、domain-g64、general-g128；teacher/checkpoint与训练/量化wheels独立收据。默认CLI路径是旧实例布局，参数允许位置更改，硬编码校准路径需恢复相同布局或另建配置并复测。
6. 从固定wheel重建policies/spec/observers overlay；补丁hash验证，不复制指向旧site-packages的symlink。
7. 六主线入口及最低成本回放。推理用dev；已冻结test不可调参。曾完成的最终test十profile使用原始结果重算，新环境复现必须新run且不重选阈值。
8. S5三轮结果离线重聚合，旧stage按照旧tag回放。不得混合跨版本聚合器声称字节完全一致。
9. 恢复与停止：record_command有进程组；run_experiment_plan核对PID身份；训练完整状态续训；benchmark整单元重测；没有后台定时上传/开机/自动唤醒。
