# 累计学习核验（材料，用户掌握尚未核验）

本材料只给出回放和口头核验任务，不能将“文件已经生成”记成用户已经独立掌握。先按各阶段README阅读，再完成下面六组练习。所有数字回答必须指向真实run、源码SHA和指标口径，不背原稿中的占位百分比。

## M1 请求、预算与观察

画出已锁定vLLM0.8.5 V0的请求进入→waiting/running→KV分配→模型执行→输出→释放。指出DriveServe插桩位置，解释为什么trace和正式计时必须分开。取一个真实mixed请求，用raw事件还原其Prefill顺序、开始Decode、共享块以及结束；拿不出事件的部分只能称推测。解释“CPU gap”“GPU忙”“显存已分配”“KV访存受限”四者为什么不能互相替代。

## M2 生命周期与数据结构

手动跟踪一个prefix从首次Prefill到再次跳过Prefill、进入hot、TTL到期、请求取消、最终block ID重用。指出引用计数和zero-ref evictor的分工。解释堆generation为何不能只存block_id，TTL浮点边界为何需要nextafter，为什么有界堆空间不等于单操作O(logN)上界。用S4维护诊断区分8192 stale pops、4352 expiry重分类、实际重建和GC，不能凭_compact方法名归因。解释小池服务与大池CPU曲线不一致为什么不是矛盾。

## M3 验证分布与控制器

从Target/Draft两组概率写出拒绝采样逻辑，说明bonus token和已接受Draft token计数区别。说明seeded序列索引重映射修复的触发条件；随机输出不要求逐token一致，但已知概率律检查必须与实际CUDA路径匹配。跟踪一次K2→3→4及回退，指出提议宽度与验证宽度，解释hold/window的作用。区分序列级教师SFT和logit蒸馏，打开训练checkpoint与SIGTERM恢复记录，说明哪些状态真的保存和恢复。最后解释“FP16组合加速而AWQ组合变慢”可以由哪些成本导致，以及现有证据是否足以指定某个kernel为原因。

## M4 量化取舍

画出FP16权重到AWQ校准、group128/64导出、vLLM后端加载的链路。明确哪些权重仍为高精度、为什么逻辑tensor bytes与nvidia-smi不同。解释通用校准118/128未过事前门槛不能事后降低门槛。拿代表层的局部误差解释group64是否值得切换，区分局部校准误差与任务准确率。同显存比例为什么不等于同KV token容量？量化Target的spec为何必须参照同一个量化Target？

## M5 并行、舍入与范围

用Q28/KV4、D128、NeoX说明输入、cache布局与slot映射。画出v1一token一个CTA和v2每token八个head tile的工作分配，解释小T为何可能受并行度限制。说明half2独立乘加与FMA的舍入差异；实际地址对齐和偶数stride如何检查；索引与可写storage别名为什么危险。读取275正确性、24非法入口和99memcheck证据，区分拒绝危险dispatch与真实执行OOB。说明Graph/Event微秒表为什么不能直接写成服务TPOT收益。

## M6 负载、尾部与两卡

用真实开环一条记录计算planned→sent lag、sent→first TTFT、planned→finish用户E2E和TPOT。构造一个已超时但未发送的请求，说明它在哪个分母里。用快/慢两个组解释为什么group goodput必须共用全cell的drain窗口。指出256×3仍无法支撑生产稳定P99的原因。比较单卡、轮询双副本、TP2的GPU预算、maxseq、KV容量和拓扑；解释S3 TP2第一轮更快原因未明时应如何表述。解释填充压力质量下降为何必须与自然业务分表。

## 核验记录方式

每次只挑一个主题，要求用户先不看稿讲一遍，再定位原始证据回答两个追问。将已回答、部分理解、需要复习分别记录；用户实际复述前全部为“待核验”。若回答中出现未做过的动词或没有条件的性能百分比，回到对应run与事实版简历修正表达。此流程是后续学习安排，不阻塞已通过工程验收的发布，也不替用户宣称面试表现。
